popupBtns = document.querySelectorAll('.show-order-status'),
popupContainer = document.querySelector('.order-status-popup')
const orderPopup = new Popup (popupBtns, popupContainer)